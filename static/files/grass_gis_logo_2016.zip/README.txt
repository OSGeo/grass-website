GRASS GIS logos downloaded from

https://grass.osgeo.org/download/logos/

- color/gray, with/without bg, slogan/just title (PNG),
- the original SVG file,
- a vectorized-font SVG file,
- Vector font variant SVG file.

-----------------------------------------------------------
More user contributed GRASS GIS Logo artwork (backgrounds etc) is available from

http://grasswiki.osgeo.org/wiki/GRASS_Art_Gallery

